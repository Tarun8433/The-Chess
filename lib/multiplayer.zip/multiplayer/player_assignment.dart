import 'dart:math';

class PlayerAssignment {
  // True if the local player is white, false if black.
  bool _isLocalPlayerWhite = true;

  /// Initializes the player assignment by randomly assigning colors.
  ///
  /// After calling this, use [isLocalPlayerWhite] to determine the local player's color.
  void assignRandomColors() {
    final random = Random();
    _isLocalPlayerWhite = random.nextBool(); // true for white, false for black
    print('Local player is: ${_isLocalPlayerWhite ? "White" : "Black"}');
  }

  /// Returns true if the local player is assigned to play as White, false otherwise.
  bool get isLocalPlayerWhite => _isLocalPlayerWhite;

  /// Determines if a player can select a piece based on the current turn and
  /// the local player's assigned color.
  ///
  /// [isPieceWhite]: The color of the piece being selected (true for white, false for black).
  /// [isWhiteTurn]: Indicates if it's currently White's turn.
  ///
  /// Returns `true` if the piece can be selected, `false` otherwise.
  bool canSelectPiece(bool isPieceWhite, bool isWhiteTurn) {
    // If it's White's turn:
    //   - Local player is White AND the piece is White, OR
    //   - Local player is Black AND the piece is Black (this condition is currently impossible
    //     if it's White's turn and the local player is black, but included for completeness
    //     if game logic changes to allow selection of opponent's pieces for certain actions).
    // If it's Black's turn:
    //   - Local player is Black AND the piece is Black, OR
    //   - Local player is White AND the piece is White (similarly, currently impossible).

    // The core logic: A player can only select a piece if it's their turn
    // AND the piece belongs to their assigned color.
    if (isWhiteTurn) {
      return _isLocalPlayerWhite && isPieceWhite;
    } else {
      return !_isLocalPlayerWhite && !isPieceWhite;
    }
  }
}