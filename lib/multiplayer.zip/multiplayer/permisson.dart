// services/permissions_service.dart (Adapted for general use)

import 'dart:io';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:package_info_plus/package_info_plus.dart';

class PermissionsService {
  // Get package information for debugging
  static Future<String> getPackageInfo() async {
    try {
      final packageInfo = await PackageInfo.fromPlatform();
      return 'Package: ${packageInfo.packageName}, Version: ${packageInfo.version}, Build: ${packageInfo.buildNumber}';
    } catch (e) {
      return 'Error getting package info: $e';
    }
  }

  static Future<bool> requestNearbyPermissions() async {
    // Log package info for debugging
    print(await getPackageInfo());
    
    List<Permission> permissions = [];

    if (Platform.isAndroid) {
      final androidInfo = await DeviceInfoPlugin().androidInfo;
      print('Android SDK: ${androidInfo.version.sdkInt}');
      print('Android Device: ${androidInfo.model}, Manufacturer: ${androidInfo.manufacturer}');

      if (androidInfo.version.sdkInt >= 31) {
        // Android 12+ (API 31+) permissions
        permissions.addAll([
          Permission.bluetoothScan,
          Permission.bluetoothConnect,
          Permission.bluetoothAdvertise,
          Permission.locationWhenInUse,
        ]);

        // NEARBY_WIFI_DEVICES is only available on Android 13+ (API 33+)
        if (androidInfo.version.sdkInt >= 33) {
          try {
            permissions.add(Permission.nearbyWifiDevices);
          } catch (e) {
            print('nearbyWifiDevices permission not available: $e');
          }
        }
      } else if (androidInfo.version.sdkInt >= 23) {
        // Android 6+ (API 23+) but less than 31
        permissions.addAll([
          Permission.bluetooth,
          Permission.locationWhenInUse,
        ]);
      } else {
        // Older Android versions
        permissions.add(Permission.bluetooth);
      }
    } else {
      // iOS permissions
      permissions.addAll([
        Permission.bluetooth,
        Permission.locationWhenInUse,
      ]);
    }

    print(
        'Requesting permissions: ${permissions.map((p) => p.toString()).toList()}');

    Map<Permission, PermissionStatus> statuses = await permissions.request();

    // Log the results
    statuses.forEach((permission, status) {
      print('$permission: $status');
    });

    bool allGranted = statuses.values.every((status) => status.isGranted);
    print('All permissions granted: $allGranted');

    return allGranted;
  }

  static Future<void> checkPermissionStatus() async {
    final permissions = [
      Permission.bluetooth,
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.bluetoothAdvertise,
      Permission.locationWhenInUse,
      Permission.nearbyWifiDevices,
    ];

    for (Permission permission in permissions) {
      try {
        final status = await permission.status;
        print('$permission: $status');
      } catch (e) {
        print('Error checking $permission: $e');
      }
    }
  }
}
