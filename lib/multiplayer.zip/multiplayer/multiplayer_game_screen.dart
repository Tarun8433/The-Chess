// ignore_for_file: constant_identifier_names

import 'package:flutter/material.dart';
import 'package:the_chess/components/chess_timer.dart';
import 'package:the_chess/components/dead_piece.dart';
import 'package:the_chess/components/timer_widget.dart';
import 'package:the_chess/multiplayer/game_board.dart';
import 'package:the_chess/multiplayer/game_start_payload.dart';
import 'package:the_chess/multiplayer/message_model.dart';
import 'package:the_chess/multiplayer/near_by_service.dart';
import 'package:the_chess/multiplayer/permisson.dart';

import 'package:flutter/services.dart'; // For HapticFeedback
import 'package:the_chess/components/pieces.dart'; // Import ChessPiece
import 'package:the_chess/components/move_history.dart'; // Import ChessMove

// Main screen for multiplayer game and chat
class MultiplayerGameScreen extends StatefulWidget {
  final String userName;

  const MultiplayerGameScreen({super.key, required this.userName});

  @override
  State<MultiplayerGameScreen> createState() => _MultiplayerGameScreenState();
}

class _MultiplayerGameScreenState extends State<MultiplayerGameScreen> {
  late NearbyService _nearbyService;
  final List<Message> _messages = [];
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _chatScrollController = ScrollController();
  bool _isConnected = false;
  String _connectedPeerName = '';
  String _connectionStatusMessage = 'Not connected';
  bool _isAdvertising = false;
  bool _isDiscovering = false;
  final Map<String, String> _foundEndpoints =
      {}; // endpointId: endpointName (for discovery)
  final Map<String, String> _incomingConnections =
      {}; // endpointId: endpointName (for advertising)

  // Reference to the BoardGame state to send updates
  final GlobalKey<BoardGameState> _boardGameKey = GlobalKey<BoardGameState>();

  bool _isLocalPlayerWhite = true; // Track local player color explicitly

  @override
  void initState() {
    super.initState();
    _nearbyService = NearbyService(
      onMessageReceived: _handleMessageReceived,
      onGameStateReceived: _handleGameStateReceived,
      onPeerConnected: _handlePeerConnected,
      onPeerDisconnected: _handlePeerDisconnected,
      onEndpointFound: _handleEndpointFound,
      onConnectionRequest: _handleConnectionRequest, // Pass the new callback
    );
  }

  @override
  void dispose() {
    _nearbyService.dispose();
    _messageController.dispose();
    _chatScrollController.dispose();
    super.dispose();
  }

  // In _handlePeerConnected method, add this logic:
  void _handlePeerConnected(String peerName) {
    setState(() {
      _isConnected = true;
      _connectedPeerName = peerName;
      _connectionStatusMessage = 'Connected to $peerName';
      _isAdvertising = false;
      _isDiscovering = false;
      _foundEndpoints.clear();
      _incomingConnections.clear();

      // Set local player color based on who initiated the connection
      // Host (advertiser) gets white, joiner gets black
      _isLocalPlayerWhite =
          _nearbyService.isAdvertising; // Use the stored advertising state
      _showColorAssignmentDialog(_isLocalPlayerWhite); // Show dialog
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            'Connected to $peerName - You are ${_isLocalPlayerWhite ? "White" : "Black"}'),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _showColorAssignmentDialog(bool isWhite) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text('Player Color Assigned!'),
        content: Text(
          'You will be playing as ${isWhite ? "White" : "Black"}.',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: isWhite
                ? Colors.white
                : Colors.black, // Adjust color based on player
          ),
        ),
        backgroundColor: isWhite
            ? Colors.blue[100]
            : Colors.grey[800], // Adjust dialog background
        titleTextStyle: TextStyle(
          color: isWhite ? Colors.black : Colors.white, // Adjust title color
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        contentTextStyle: TextStyle(
          color: isWhite ? Colors.black : Colors.white, // Adjust content color
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text(
              'OK',
              style:
                  TextStyle(color: isWhite ? Colors.blue[900] : Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  // Update the BoardGame widget call:
  Widget _buildGameAndChatInterface() {
    return Container(
      color: Colors.black87,
      child: Column(
        children: [
          // // Opponent's captured pieces and timer (will be at the top for local white, bottom for local black)
          // if (!_isLocalPlayerWhite) // If local player is black, show white pieces at top
          //   _buildPlayerInfo(
          //     playerName: "Tarun Ku. Sahani", // Opponent's name
          //     capturedPieces:
          //         _boardGameKey.currentState?.currentWhitePiecesTaken ?? [],
          //     isWhitePlayer: true,
          //     chessTimerDisplay: ChessTimerDisplayForWhite(
          //       chessTimer: _boardGameKey.currentState?.chessTimer ??
          //           ChessTimer.customTimer(
          //             onTimeUpdate: (w, b) {},
          //             onTimeUp: (w) {},
          //             initialTime: Duration(minutes: 5),
          //           ), // Pass a dummy if null
          //       whiteTime: _boardGameKey.currentState?.whiteTime ??
          //           Duration(minutes: 10),
          //       blackTime: _boardGameKey.currentState?.blackTime ??
          //           Duration(minutes: 10),
          //     ),
          //     isInReviewMode:
          //         _boardGameKey.currentState?.reviewController.isInReviewMode ??
          //             false,
          //   )
          // else // If local player is white, show black pieces at top
          //   _buildPlayerInfo(
          //     playerName: "Tarun Ku. Sahani", // Opponent's name
          //     capturedPieces:
          //         _boardGameKey.currentState?.currentBlackPiecesTaken ?? [],
          //     isWhitePlayer: false,
          //     chessTimerDisplay: ChessTimerDisplayForBlack(
          //       chessTimer: _boardGameKey.currentState?.chessTimer ??
          //           ChessTimer.customTimer(
          //             onTimeUpdate: (w, b) {},
          //             onTimeUp: (w) {},
          //             initialTime: Duration(minutes: 5),
          //           ), // Pass a dummy if null
          //       whiteTime: _boardGameKey.currentState?.whiteTime ??
          //           Duration(minutes: 10),
          //       blackTime: _boardGameKey.currentState?.blackTime ??
          //           Duration(minutes: 10),
          //     ),
          //     isInReviewMode:
          //         _boardGameKey.currentState?.reviewController.isInReviewMode ??
          //             false,
          //   ),

          // Spacer(),

          Expanded(
            flex: 3,
            child: BoardGame(
              key: _boardGameKey,
              onGameStateUpdate: _sendGameStateUpdate,
              isMultiplayer: true,
              isLocalPlayerWhite:
                  _isLocalPlayerWhite, // Use the explicit variable
              name: widget.userName,
            ),
          ),

          // Spacer(),

          // Local player's captured pieces and timer (will be at the bottom)
          // if (_isLocalPlayerWhite) // If local player is white, show white pieces at bottom
          //   _buildPlayerInfo(
          //     playerName: widget.userName, // Local player's name
          //     capturedPieces:
          //         _boardGameKey.currentState?.currentWhitePiecesTaken ?? [],
          //     isWhitePlayer: true,
          //     chessTimerDisplay: ChessTimerDisplayForWhite(
          //       chessTimer: _boardGameKey.currentState?.chessTimer ??
          //           ChessTimer.customTimer(
          //             onTimeUpdate: (w, b) {},
          //             onTimeUp: (w) {},
          //             initialTime: Duration(minutes: 5),
          //           ), // Pass a dummy if null
          //       whiteTime: _boardGameKey.currentState?.whiteTime ??
          //           Duration(minutes: 10),
          //       blackTime: _boardGameKey.currentState?.blackTime ??
          //           Duration(minutes: 10),
          //     ),
          //     isInReviewMode:
          //         _boardGameKey.currentState?.reviewController.isInReviewMode ??
          //             false,
          //   )
          // else // If local player is black, show black pieces at bottom
          //   _buildPlayerInfo(
          //     playerName: widget.userName, // Local player's name
          //     capturedPieces:
          //         _boardGameKey.currentState?.currentBlackPiecesTaken ?? [],
          //     isWhitePlayer: false,
          //     chessTimerDisplay: ChessTimerDisplayForBlack(
          //       chessTimer: _boardGameKey.currentState?.chessTimer ??
          //           ChessTimer.customTimer(
          //             onTimeUpdate: (w, b) {},
          //             onTimeUp: (w) {},
          //             initialTime: Duration(minutes: 5),
          //           ), // Pass a dummy if null
          //       whiteTime: _boardGameKey.currentState?.whiteTime ??
          //           Duration(minutes: 10),
          //       blackTime: _boardGameKey.currentState?.blackTime ??
          //           Duration(minutes: 10),
          //     ),
          //     isInReviewMode:
          //         _boardGameKey.currentState?.reviewController.isInReviewMode ??
          //             false,
          //   ),

          // const Divider(height: 1, color: Colors.grey),
          // Expanded(
          //   flex: 1, // Allocate space for chat
          //   child: Column(
          //     children: [
          //       Expanded(
          //         child: ListView.builder(
          //           controller: _chatScrollController,
          //           itemCount: _messages.length,
          //           itemBuilder: (context, index) {
          //             final message = _messages[index];
          //             return _buildMessageBubble(message);
          //           },
          //         ),
          //       ),
          //       //  _buildMessageInput(),
          //     ],
          //   ),
          // ),
        ],
      ),
    );
  }

  // Helper widget to build player info rows (replaces duplicated code)
  Widget _buildPlayerInfo({
    required String playerName,
    required List<ChessPiece> capturedPieces,
    required bool isWhitePlayer,
    required Widget chessTimerDisplay,
    required bool isInReviewMode,
  }) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                decoration:
                    BoxDecoration(border: Border.all(color: Colors.white)),
                child: Image.asset(
                  "assets/images/figures/white/queen.png", // This image might need to be dynamic based on player color
                  height: 50,
                ),
              ),
              SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    playerName,
                    style: TextStyle(
                      color: isInReviewMode ? Colors.black : Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                  SizedBox(
                    height: 30,
                    width: MediaQuery.of(context).size.width * .6,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      shrinkWrap: true,
                      physics: const BouncingScrollPhysics(),
                      itemCount: capturedPieces.length,
                      itemBuilder: (context, index) => DeadPiece(
                        imagePath: capturedPieces[index].imagePath,
                        isWhite: isWhitePlayer,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          chessTimerDisplay,
        ],
      ),
    );
  }

  // Also store the advertising state when starting to advertise
  void _startAdvertising() async {
    bool granted = await PermissionsService.requestNearbyPermissions();
    if (granted) {
      _nearbyService.stopDiscovery();
      await _nearbyService.startAdvertising(widget.userName);
      setState(() {
        _isAdvertising = true;
        _isDiscovering = false;
        _connectionStatusMessage = 'Advertising... Waiting for connections';
        _foundEndpoints.clear();
        _isLocalPlayerWhite = true; // Host is always white
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Hosting game as White player...'),
          backgroundColor: Colors.blue,
        ),
      );
    } else {
      _showPermissionError();
    }
  }

  void _startDiscovery() async {
    bool granted = await PermissionsService.requestNearbyPermissions();
    if (granted) {
      _nearbyService.stopAdvertising();
      await _nearbyService.startDiscovery(widget.userName);
      setState(() {
        _isDiscovering = true;
        _isAdvertising = false;
        _connectionStatusMessage = 'Discovering nearby devices...';
        _incomingConnections.clear();
        _isLocalPlayerWhite = false; // Joiner is always black
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Looking to join as Black player...'),
          backgroundColor: Colors.green,
        ),
      );
    } else {
      _showPermissionError();
    }
  }

  void _handleMessageReceived(String endpointId, Message message) {
    setState(() {
      _messages.add(message);
    });
    _scrollToBottom();
    HapticFeedback.lightImpact(); // Vibrate on message
  }

  void _handleGameStateReceived(String endpointId, GameStatePayload payload) {
    // Apply the received game state to the BoardGame
    // Convert lastMoveJson back to ChessMove if present
    ChessMove? lastMove;
    if (payload.lastMoveJson != null) {
      lastMove = ChessMove.fromJson(payload.lastMoveJson!);
    }
    _boardGameKey.currentState?.applyGameState(
      payload.board,
      payload.whitePiecesTaken,
      payload.blackPiecesTaken,
      payload.isWhiteTurn,
      payload.whiteKingPosition,
      payload.blackKingPosition,
      payload.checkStatus,
      payload.enPassantTarget,
      lastMove,
    );
  }

  void _handlePeerDisconnected() {
    setState(() {
      _isConnected = false;
      _connectedPeerName = '';
      _connectionStatusMessage = 'Disconnected';
      _isAdvertising = false;
      _isDiscovering = false;
      _foundEndpoints.clear();
      _incomingConnections.clear();
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Peer disconnected'),
        backgroundColor: Colors.orange,
      ),
    );
  }

  void _handleEndpointFound(
      String endpointId, String endpointName, String serviceId) {
    setState(() {
      // Only add to foundEndpoints if not already connected and not an incoming connection (which is handled separately)
      if (!_isConnected && !_incomingConnections.containsKey(endpointId)) {
        _foundEndpoints[endpointId] = endpointName;
      }
    });
  }

  void _handleConnectionRequest(
      String endpointId, String endpointName, String serviceId) {
    setState(() {
      _incomingConnections[endpointId] = endpointName;
      // Optionally show a dialog here for the user to accept/reject
      _showConnectionRequestDialog(endpointId, endpointName);
    });
  }

  void _showConnectionRequestDialog(String endpointId, String endpointName) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Connection Request'),
        content: Text('Do you want to accept a connection from $endpointName?'),
        actions: [
          TextButton(
            onPressed: () {
              _nearbyService.rejectConnection(endpointId);
              setState(() {
                _incomingConnections.remove(endpointId);
              });
              Navigator.of(context).pop();
            },
            child: const Text('Reject'),
          ),
          ElevatedButton(
            onPressed: () {
              _nearbyService.acceptConnection(endpointId);
              setState(() {
                _incomingConnections.remove(
                    endpointId); // Will be cleared by _handlePeerConnected too
              });
              Navigator.of(context).pop();
            },
            child: const Text('Accept'),
          ),
        ],
      ),
    );
  }

  void _requestConnection(String endpointId) {
    _nearbyService.requestConnection(widget.userName, endpointId);
    setState(() {
      _connectionStatusMessage =
          'Requesting connection to ${_foundEndpoints[endpointId]}...';
    });
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_chatScrollController.hasClients) {
        _chatScrollController.animateTo(
          _chatScrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _showPermissionError() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Nearby permissions are required to use this feature'),
        backgroundColor: Colors.red,
      ),
    );
  }

  // Callback from BoardGame to send game state
  void _sendGameStateUpdate(
    List<List<ChessPiece?>> board,
    List<ChessPiece> whitePiecesTaken,
    List<ChessPiece> blackPiecesTaken,
    bool isWhiteTurn,
    List<int> whiteKingPosition,
    List<int> blackKingPosition,
    bool checkStatus,
    List<int>? enPassantTarget,
    ChessMove? lastMove,
  ) {
    if (!_isConnected) return;

    // Convert ChessPiece objects to a serializable format (Map<String, dynamic>)
    List<List<Map<String, dynamic>?>> serializableBoard = board.map((row) {
      return row.map((piece) => piece?.toJson()).toList();
    }).toList();

    List<Map<String, dynamic>> serializableWhiteTaken =
        whitePiecesTaken.map((piece) => piece.toJson()).toList();
    List<Map<String, dynamic>> serializableBlackTaken =
        blackPiecesTaken.map((piece) => piece.toJson()).toList();

    final gameStatePayload = GameStatePayload(
      board: serializableBoard,
      whitePiecesTaken: serializableWhiteTaken,
      blackPiecesTaken: serializableBlackTaken,
      isWhiteTurn: isWhiteTurn,
      whiteKingPosition: whiteKingPosition,
      blackKingPosition: blackKingPosition,
      checkStatus: checkStatus,
      enPassantTarget: enPassantTarget,
      lastMoveJson: lastMove?.toJson(), // Send the last move made as JSON
    );
    _nearbyService.sendGameState(gameStatePayload);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isConnected
            ? 'Connected: $_connectedPeerName'
            : 'Multiplayer Chess'),
        backgroundColor: _isConnected ? Colors.green : Colors.blue,
        foregroundColor: Colors.white,
        actions: [
          if (_isConnected)
            IconButton(
              icon: const Icon(Icons.close),
              onPressed: () {
                _nearbyService.disconnect();
                _handlePeerDisconnected();
              },
            ),
        ],
      ),
      body: _isConnected
          ? _buildGameAndChatInterface()
          : _buildConnectionOptions(),
    );
  }

// Enhanced connection options UI with better status tracking
  Widget _buildConnectionOptions() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.wifi_tethering, size: 100, color: Colors.blue),
            const SizedBox(height: 20),
            const Text(
              'Multiplayer Chess Connection',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _getStatusColor().withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _getStatusColor().withOpacity(0.3)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(_getStatusIcon(), color: _getStatusColor(), size: 20),
                  SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      _connectionStatusMessage,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 16,
                        color: _getStatusColor(),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
            if (!_isAdvertising && !_isDiscovering) // Show buttons initially
              Column(
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _startAdvertising,
                      icon: const Icon(Icons.broadcast_on_personal),
                      label: const Text('Host Game (Play as White)'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 15),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _startDiscovery,
                      icon: const Icon(Icons.search),
                      label: const Text('Join Game (Play as Black)'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 15),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Make sure both devices have Bluetooth and Location enabled',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[600],
                      fontStyle: FontStyle.italic,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            if (_isAdvertising) // Show current advertising status and incoming requests
              Column(
                children: [
                  const CircularProgressIndicator(color: Colors.blue),
                  const SizedBox(height: 10),
                  Text(
                    'Waiting for players to join...',
                    style: TextStyle(fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 20),
                  if (_incomingConnections.isNotEmpty)
                    Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.blue.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.blue.withOpacity(0.3)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.person_add,
                                  color: Colors.blue, size: 20),
                              SizedBox(width: 8),
                              Text(
                                'Connection Requests:',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue[800],
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 12),
                          ..._incomingConnections.entries
                              .map((entry) => Container(
                                    margin: EdgeInsets.only(bottom: 8),
                                    padding: EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                          color: Colors.grey.withOpacity(0.3)),
                                    ),
                                    child: Row(
                                      children: [
                                        CircleAvatar(
                                          radius: 16,
                                          backgroundColor: Colors.green,
                                          child: Icon(Icons.person,
                                              color: Colors.white, size: 16),
                                        ),
                                        SizedBox(width: 12),
                                        Expanded(
                                          child: Text(
                                            entry.value,
                                            style: TextStyle(
                                                fontWeight: FontWeight.w500),
                                          ),
                                        ),
                                        IconButton(
                                          icon: const Icon(Icons.check_circle,
                                              color: Colors.green),
                                          onPressed: () {
                                            _nearbyService
                                                .acceptConnection(entry.key);
                                            setState(() {
                                              _incomingConnections
                                                  .remove(entry.key);
                                            });
                                          },
                                          tooltip: 'Accept',
                                        ),
                                        IconButton(
                                          icon: const Icon(Icons.cancel,
                                              color: Colors.red),
                                          onPressed: () {
                                            _nearbyService
                                                .rejectConnection(entry.key);
                                            setState(() {
                                              _incomingConnections
                                                  .remove(entry.key);
                                            });
                                          },
                                          tooltip: 'Decline',
                                        ),
                                      ],
                                    ),
                                  )),
                        ],
                      ),
                    ),
                  const SizedBox(height: 20),
                  ElevatedButton.icon(
                    onPressed: () {
                      _nearbyService.stopAdvertising();
                      setState(() {
                        _isAdvertising = false;
                        _connectionStatusMessage = 'Stopped hosting';
                        _incomingConnections.clear();
                      });
                    },
                    icon: const Icon(Icons.stop),
                    label: const Text('Stop Hosting'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey[600],
                      foregroundColor: Colors.white,
                    ),
                  ),
                ],
              ),
            if (_isDiscovering) // Show current discovering status and found devices
              Column(
                children: [
                  const CircularProgressIndicator(color: Colors.green),
                  const SizedBox(height: 10),
                  Text(
                    'Searching for nearby games...',
                    style: TextStyle(fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 20),
                  if (_foundEndpoints.isNotEmpty)
                    Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border:
                            Border.all(color: Colors.green.withOpacity(0.3)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.wifi_find,
                                  color: Colors.green, size: 20),
                              SizedBox(width: 8),
                              Text(
                                'Available Games:',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.green[800],
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 12),
                          ..._foundEndpoints.entries.map((entry) => Container(
                                margin: EdgeInsets.only(bottom: 8),
                                padding: EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                      color: Colors.grey.withOpacity(0.3)),
                                ),
                                child: Row(
                                  children: [
                                    CircleAvatar(
                                      radius: 16,
                                      backgroundColor: Colors.blue,
                                      child: Icon(Icons.sports_esports,
                                          color: Colors.white, size: 16),
                                    ),
                                    SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            entry.value,
                                            style: TextStyle(
                                                fontWeight: FontWeight.w500),
                                          ),
                                          Text(
                                            'Tap to join as Black player',
                                            style: TextStyle(
                                              fontSize: 12,
                                              color: Colors.grey[600],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    ElevatedButton(
                                      onPressed: () =>
                                          _requestConnection(entry.key),
                                      child: const Text('Join'),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.green,
                                        foregroundColor: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              )),
                        ],
                      ),
                    )
                  else
                    Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.orange.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                        border:
                            Border.all(color: Colors.orange.withOpacity(0.3)),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.info_outline, color: Colors.orange),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'No games found yet. Make sure the host is advertising nearby.',
                              style: TextStyle(color: Colors.orange[800]),
                            ),
                          ),
                        ],
                      ),
                    ),
                  const SizedBox(height: 20),
                  ElevatedButton.icon(
                    onPressed: () {
                      _nearbyService.stopDiscovery();
                      setState(() {
                        _isDiscovering = false;
                        _connectionStatusMessage = 'Stopped searching';
                        _foundEndpoints.clear();
                      });
                    },
                    icon: const Icon(Icons.stop),
                    label: const Text('Stop Searching'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey[600],
                      foregroundColor: Colors.white,
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

// Helper methods for status indication
  Color _getStatusColor() {
    if (_isConnected) return Colors.green;
    if (_isAdvertising) return Colors.blue;
    if (_isDiscovering) return Colors.orange;
    return Colors.grey;
  }

  IconData _getStatusIcon() {
    if (_isConnected) return Icons.check_circle;
    if (_isAdvertising) return Icons.broadcast_on_personal;
    if (_isDiscovering) return Icons.search;
    return Icons.info_outline;
  }
  // Widget _buildConnectionOptions() {
  //   return Center(
  //     child: Padding(
  //       padding: const EdgeInsets.all(20.0),
  //       child: Column(
  //         mainAxisAlignment: MainAxisAlignment.center,
  //         children: [
  //           const Icon(Icons.wifi_tethering, size: 100, color: Colors.blue),
  //           const SizedBox(height: 20),
  //           const Text(
  //             'Multiplayer Chess Connection',
  //             style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
  //           ),
  //           const SizedBox(height: 10),
  //           Text(
  //             _connectionStatusMessage,
  //             textAlign: TextAlign.center,
  //             style: TextStyle(fontSize: 16, color: Colors.grey[600]),
  //           ),
  //           const SizedBox(height: 40),
  //           if (!_isAdvertising && !_isDiscovering) // Show buttons initially
  //             Column(
  //               children: [
  //                 SizedBox(
  //                   width: double.infinity,
  //                   child: ElevatedButton.icon(
  //                     onPressed: _startAdvertising,
  //                     icon: const Icon(Icons.broadcast_on_personal),
  //                     label: const Text('Host Game'),
  //                     style: ElevatedButton.styleFrom(
  //                       backgroundColor: Colors.blue,
  //                       foregroundColor: Colors.white,
  //                       padding: const EdgeInsets.symmetric(vertical: 15),
  //                     ),
  //                   ),
  //                 ),
  //                 const SizedBox(height: 20),
  //                 SizedBox(
  //                   width: double.infinity,
  //                   child: ElevatedButton.icon(
  //                     onPressed: _startDiscovery,
  //                     icon: const Icon(Icons.search),
  //                     label: const Text('Join Game'),
  //                     style: ElevatedButton.styleFrom(
  //                       backgroundColor: Colors.green,
  //                       foregroundColor: Colors.white,
  //                       padding: const EdgeInsets.symmetric(vertical: 15),
  //                     ),
  //                   ),
  //                 ),
  //               ],
  //             ),
  //           if (_isAdvertising) // Show current advertising status and incoming requests
  //             Column(
  //               children: [
  //                 const CircularProgressIndicator(color: Colors.blue),
  //                 const SizedBox(height: 10),
  //                 Text(_connectionStatusMessage),
  //                 const SizedBox(height: 20),
  //                 if (_incomingConnections.isNotEmpty)
  //                   Column(
  //                     crossAxisAlignment: CrossAxisAlignment.start,
  //                     children: [
  //                       const Text('Incoming Connection Requests:',
  //                           style: TextStyle(fontWeight: FontWeight.bold)),
  //                       ..._incomingConnections.entries.map((entry) => ListTile(
  //                             title: Text(entry.value),
  //                             trailing: Row(
  //                               mainAxisSize: MainAxisSize.min,
  //                               children: [
  //                                 IconButton(
  //                                   icon: const Icon(Icons.check,
  //                                       color: Colors.green),
  //                                   onPressed: () => _nearbyService
  //                                       .acceptConnection(entry.key),
  //                                 ),
  //                                 IconButton(
  //                                   icon: const Icon(Icons.close,
  //                                       color: Colors.red),
  //                                   onPressed: () => _nearbyService
  //                                       .rejectConnection(entry.key),
  //                                 ),
  //                               ],
  //                             ),
  //                           )),
  //                     ],
  //                   ),
  //                 const SizedBox(height: 20),
  //                 ElevatedButton(
  //                   onPressed: () {
  //                     _nearbyService.stopAdvertising();
  //                     setState(() {
  //                       _isAdvertising = false;
  //                       _connectionStatusMessage = 'Advertising stopped.';
  //                       _incomingConnections.clear();
  //                     });
  //                   },
  //                   child: const Text('Stop Hosting'),
  //                 ),
  //               ],
  //             ),
  //           if (_isDiscovering) // Show current discovering status and found devices
  //             Column(
  //               children: [
  //                 const CircularProgressIndicator(color: Colors.green),
  //                 const SizedBox(height: 10),
  //                 Text(_connectionStatusMessage),
  //                 const SizedBox(height: 20),
  //                 if (_foundEndpoints.isNotEmpty)
  //                   Column(
  //                     crossAxisAlignment: CrossAxisAlignment.start,
  //                     children: [
  //                       const Text('Found Devices:',
  //                           style: TextStyle(fontWeight: FontWeight.bold)),
  //                       ..._foundEndpoints.entries.map((entry) => ListTile(
  //                             title: Text(entry.value),
  //                             trailing: ElevatedButton(
  //                               onPressed: () => _requestConnection(entry.key),
  //                               child: const Text('Connect'),
  //                             ),
  //                           )),
  //                     ],
  //                   ),
  //                 const SizedBox(height: 20),
  //                 ElevatedButton(
  //                   onPressed: () {
  //                     _nearbyService.stopDiscovery();
  //                     setState(() {
  //                       _isDiscovering = false;
  //                       _connectionStatusMessage = 'Discovery stopped.';
  //                       _foundEndpoints.clear();
  //                     });
  //                   },
  //                   child: const Text('Stop Discovery'),
  //                 ),
  //               ],
  //             ),
  //         ],
  //       ),
  //     ),
  //   );
  // }
}
