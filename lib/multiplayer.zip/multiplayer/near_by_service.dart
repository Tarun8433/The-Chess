// Enhanced NearbyService with better connection handling
import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:the_chess/multiplayer/game_start_payload.dart';
import 'package:the_chess/multiplayer/message_model.dart';
import 'package:nearby_connections/nearby_connections.dart'
    as nearby_connections;
import 'package:the_chess/multiplayer/permisson.dart'; // Alias to avoid conflict


class NearbyService {
  final Function(String, Message) onMessageReceived;
  final Function(String, GameStatePayload) onGameStateReceived;
  final Function(String) onPeerConnected;
  final Function() onPeerDisconnected;
  final Function(String, String, String) onEndpointFound;
  final Function(String endpointId, String endpointName, String serviceId)
      onConnectionRequest;

  String? _connectedEndpointId;
  String? _connectedEndpointName;
  bool _isAdvertising = false;
  bool _isDiscovering = false;
  final nearby_connections.Strategy strategy =
      nearby_connections.Strategy.P2P_STAR;

  // Add timeout and retry mechanism
  Timer? _connectionTimeout;
  static const int CONNECTION_TIMEOUT_SECONDS = 30;

  // Track connection attempts to prevent spam
  final Map<String, DateTime> _connectionAttempts = {};
  static const int MIN_CONNECTION_RETRY_DELAY_MS = 2000; // 2 seconds

  NearbyService({
    required this.onMessageReceived,
    required this.onGameStateReceived,
    required this.onPeerConnected,
    required this.onPeerDisconnected,
    required this.onEndpointFound,
    required this.onConnectionRequest,
  });

  String? get connectedEndpointId => _connectedEndpointId;
  String? get connectedEndpointName => _connectedEndpointName;
  bool get isConnected => _connectedEndpointId != null;
  bool get isAdvertising => _isAdvertising;
  bool get isDiscovering => _isDiscovering;

  Future<void> startAdvertising(String userName) async {
    try {
      // Get package info for debugging
      final packageInfo = await PermissionsService.getPackageInfo();
      print('Starting advertising with $packageInfo');
      
      if (!await PermissionsService.requestNearbyPermissions()) {
        print('Permissions not granted for advertising.');
        return;
      }

      // Clean stop any existing operations
      await _cleanStop();

      // Small delay to ensure clean state
      await Future.delayed(Duration(milliseconds: 500));

      try {
        await nearby_connections.Nearby().startAdvertising(
          userName,
          strategy,
          onConnectionInitiated:
              (String endpointId, nearby_connections.ConnectionInfo info) {
            print(
                '🔄 Connection initiated from ${info.endpointName} (${info.authenticationToken})');
            _handleConnectionInitiated(endpointId, info, userName);
          },
          onConnectionResult:
              (String endpointId, nearby_connections.Status status) {
            print('📡 Connection result for $endpointId: $status');
            _handleConnectionResult(endpointId, status);
          },
          onDisconnected: (String endpointId) {
            print('❌ Disconnected from $endpointId');
            _handleDisconnected(endpointId);
          },
          serviceId: 'com.chess.game', // Add explicit service ID
        );
        _isAdvertising = true;
        print('✅ Advertising started by $userName');
      } catch (e) {
        print('❌ Error in Nearby.startAdvertising: $e');
        if (e.toString().contains('SecurityException') || 
            e.toString().contains('Unknown calling package name')) {
          print('This appears to be a package name verification issue. ' +
              'Make sure the app is properly signed and the package name is registered.');
        }
        _isAdvertising = false;
        rethrow;
      }
    } catch (e) {
      print('❌ Error starting advertising: $e');
      _isAdvertising = false;
    }
  }

  Future<void> startDiscovery(String userName) async {
    try {
      // Get package info for debugging
      final packageInfo = await PermissionsService.getPackageInfo();
      print('Starting discovery with $packageInfo');
      
      if (!await PermissionsService.requestNearbyPermissions()) {
        print('Permissions not granted for discovery.');
        return;
      }

      // Clean stop any existing operations
      await _cleanStop();

      // Small delay to ensure clean state
      await Future.delayed(Duration(milliseconds: 500));

      try {
        await nearby_connections.Nearby().startDiscovery(
          userName,
          strategy,
          onEndpointFound:
              (String endpointId, String endpointName, String serviceId) {
            print('🔍 Found endpoint: $endpointName ($endpointId) with service: $serviceId');
            onEndpointFound(endpointId, endpointName, serviceId);
          },
          onEndpointLost: (endpointId) {
            print('📍 Endpoint lost: $endpointId');
            // Clean up any pending connection attempts for this endpoint
            _connectionAttempts.remove(endpointId);
          },
          serviceId: 'com.chess.game', // Add explicit service ID
        );
        _isDiscovering = true;
        print('🔍 Discovery started by $userName');
      } catch (e) {
        print('❌ Error in Nearby.startDiscovery: $e');
        if (e.toString().contains('SecurityException') || 
            e.toString().contains('Unknown calling package name')) {
          print('This appears to be a package name verification issue. ' +
              'Make sure the app is properly signed and the package name is registered.');
        }
        _isDiscovering = false;
        rethrow;
      }
    } catch (e) {
      print('❌ Error starting discovery: $e');
      _isDiscovering = false;
    }
  }

  void requestConnection(String userName, String endpointId) {
    // Check if we recently attempted to connect to this endpoint
    if (_connectionAttempts.containsKey(endpointId)) {
      DateTime lastAttempt = _connectionAttempts[endpointId]!;
      int timeSinceLastAttempt = DateTime.now().millisecondsSinceEpoch -
          lastAttempt.millisecondsSinceEpoch;

      if (timeSinceLastAttempt < MIN_CONNECTION_RETRY_DELAY_MS) {
        print(
            '⏰ Skipping connection request to $endpointId - too soon after last attempt');
        return;
      }
    }

    print('🤝 Requesting connection to $endpointId as $userName');
    _connectionAttempts[endpointId] = DateTime.now();

    // Set connection timeout
    _connectionTimeout?.cancel();
    _connectionTimeout =
        Timer(Duration(seconds: CONNECTION_TIMEOUT_SECONDS), () {
      print('⏱️ Connection timeout for $endpointId');
      _connectionAttempts.remove(endpointId);
    });

    nearby_connections.Nearby().requestConnection(
      userName,
      endpointId,
      onConnectionInitiated:
          (String endpointId, nearby_connections.ConnectionInfo info) {
        print(
            '🔄 Connection initiated to ${info.endpointName} (${info.authenticationToken})');
        _handleConnectionInitiated(endpointId, info, userName);
      },
      onConnectionResult:
          (String endpointId, nearby_connections.Status status) {
        print('📡 Connection result for $endpointId: $status');
        _connectionTimeout?.cancel();
        _connectionAttempts.remove(endpointId);
        _handleConnectionResult(endpointId, status);
      },
      onDisconnected: (String endpointId) {
        print('❌ Disconnected from $endpointId');
        _connectionTimeout?.cancel();
        _connectionAttempts.remove(endpointId);
        _handleDisconnected(endpointId);
      },
    );
  }

  void acceptConnection(String endpointId) {
    print('✅ Accepting connection from $endpointId');
    nearby_connections.Nearby().acceptConnection(endpointId,
        onPayLoadRecieved: (endpointId, payload) {
      _handlePayloadReceived(endpointId, payload);
    });
  }

  void rejectConnection(String endpointId) {
    print('❌ Rejecting connection from $endpointId');
    nearby_connections.Nearby().rejectConnection(endpointId);
    _connectionAttempts.remove(endpointId);
  }

  void _handleConnectionInitiated(String endpointId,
      nearby_connections.ConnectionInfo info, String userName) {
    print('🔗 Connection initiated with ${info.endpointName}');
    _connectedEndpointName = info.endpointName; // Store the name early

    // For debugging - show the authentication token
    print('🔐 Authentication token: ${info.authenticationToken}');

    // Notify UI for user confirmation
    onConnectionRequest(
        endpointId, info.endpointName, info.authenticationToken);
  }

  void _handleConnectionResult(
      String endpointId, nearby_connections.Status status) {
    if (status == nearby_connections.Status.CONNECTED) {
      _connectedEndpointId = endpointId;
      _connectedEndpointName = _connectedEndpointName ?? 'Unknown Peer';

      print(
          '✅ Successfully connected to $_connectedEndpointName ($endpointId)');
      onPeerConnected(_connectedEndpointName!);

      // Stop advertising/discovery once connected
      _stopOperations();
    } else {
      print(
          '❌ Connection to $_connectedEndpointName ($endpointId) failed: $status');
      _connectedEndpointId = null;
      _connectedEndpointName = null;
    }
  }

  void _handleDisconnected(String endpointId) {
    print('🔌 Disconnected from $_connectedEndpointName ($endpointId)');
    _connectedEndpointId = null;
    _connectedEndpointName = null;
    _connectionTimeout?.cancel();
    onPeerDisconnected();
  }

  void _handlePayloadReceived(
      String endpointId, nearby_connections.Payload payload) {
    if (payload.type == nearby_connections.PayloadType.BYTES) {
      String data = String.fromCharCodes(payload.bytes!);
      try {
        Map<String, dynamic> decoded = jsonDecode(data);
        String type = decoded['type'];

        if (type == CustomPayloadType.chatMessage.name) {
          Message msg = Message.fromJson(decoded['data']);
          onMessageReceived(endpointId, msg);
        } else if (type == CustomPayloadType.gameState.name) {
          GameStatePayload gameState =
              GameStatePayload.fromJson(decoded['data']);
          onGameStateReceived(endpointId, gameState);
        }
      } catch (e) {
        print('❌ Error decoding payload: $e, Raw data: $data');
      }
    }
  }

  void sendMessage(Message message) {
    if (_connectedEndpointId != null) {
      final payloadData = {
        'type': CustomPayloadType.chatMessage.name,
        'data': message.toJson(),
      };
      nearby_connections.Nearby().sendBytesPayload(_connectedEndpointId!,
          Uint8List.fromList(jsonEncode(payloadData).codeUnits));
      print('💬 Message sent to $_connectedEndpointId');
    } else {
      print('❌ Not connected to any peer to send message.');
    }
  }

  void sendGameState(GameStatePayload gameState) {
    if (_connectedEndpointId != null) {
      final payloadData = {
        'type': CustomPayloadType.gameState.name,
        'data': gameState.toJson(),
      };
      nearby_connections.Nearby().sendBytesPayload(_connectedEndpointId!,
          Uint8List.fromList(jsonEncode(payloadData).codeUnits));
      print('🎮 Game state sent to $_connectedEndpointId');
    } else {
      print('❌ Not connected to any peer to send game state.');
    }
  }

  Future<void> _cleanStop() async {
    try {
      nearby_connections.Nearby().stopAdvertising();
      nearby_connections.Nearby().stopDiscovery();

      // Small delay to ensure operations are stopped
      await Future.delayed(Duration(milliseconds: 200));
    } catch (e) {
      print('⚠️ Error during clean stop: $e');
    }
  }

  void _stopOperations() {
    if (_isAdvertising) {
      nearby_connections.Nearby().stopAdvertising();
      _isAdvertising = false;
      print('🛑 Advertising stopped.');
    }

    if (_isDiscovering) {
      nearby_connections.Nearby().stopDiscovery();
      _isDiscovering = false;
      print('🛑 Discovery stopped.');
    }

    // Clear connection attempts
    _connectionAttempts.clear();
  }

  void stopAdvertising() {
    if (_isAdvertising) {
      nearby_connections.Nearby().stopAdvertising();
      _isAdvertising = false;
      print('🛑 Advertising stopped.');
    }
  }

  void stopDiscovery() {
    if (_isDiscovering) {
      nearby_connections.Nearby().stopDiscovery();
      _isDiscovering = false;
      print('🛑 Discovery stopped.');
    }
  }

  void disconnect() {
    _connectionTimeout?.cancel();

    if (_connectedEndpointId != null) {
      nearby_connections.Nearby().disconnectFromEndpoint(_connectedEndpointId!);
      _connectedEndpointId = null;
      _connectedEndpointName = null;
      print('🔌 Disconnected from current peer.');
    }

    _stopOperations();
    _connectionAttempts.clear();
  }

  void dispose() {
    _connectionTimeout?.cancel();
    disconnect();
  }
}
