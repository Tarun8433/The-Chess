// Data model for game state synchronization
class GameStatePayload {
  final List<List<Map<String, dynamic>?>> board;
  final List<Map<String, dynamic>> whitePiecesTaken;
  final List<Map<String, dynamic>> blackPiecesTaken;
  final bool isWhiteTurn;
  final List<int> whiteKingPosition;
  final List<int> blackKingPosition;
  final bool checkStatus;
  final List<int>? enPassantTarget;
  final Map<String, dynamic>?
      lastMoveJson; // To send the last move made as JSON

  GameStatePayload({
    required this.board,
    required this.whitePiecesTaken,
    required this.blackPiecesTaken,
    required this.isWhiteTurn,
    required this.whiteKingPosition,
    required this.blackKingPosition,
    required this.checkStatus,
    this.enPassantTarget,
    this.lastMoveJson,
  });

  Map<String, dynamic> toJson() {
    return {
      'board': board,
      'whitePiecesTaken': whitePiecesTaken,
      'blackPiecesTaken': blackPiecesTaken,
      'isWhiteTurn': isWhiteTurn,
      'whiteKingPosition': whiteKingPosition,
      'blackKingPosition': blackKingPosition,
      'checkStatus': checkStatus,
      'enPassantTarget': enPassantTarget,
      'lastMove': lastMoveJson,
    };
  }

  factory GameStatePayload.fromJson(Map<String, dynamic> json) {
    return GameStatePayload(
      board: (json['board'] as List)
          .map((row) => (row as List)
              .map((pieceJson) => pieceJson != null
                  ? Map<String, dynamic>.from(pieceJson)
                  : null)
              .toList())
          .toList(),
      whitePiecesTaken: (json['whitePiecesTaken'] as List)
          .map((e) => Map<String, dynamic>.from(e))
          .toList(),
      blackPiecesTaken: (json['blackPiecesTaken'] as List)
          .map((e) => Map<String, dynamic>.from(e))
          .toList(),
      isWhiteTurn: json['isWhiteTurn'],
      whiteKingPosition: List<int>.from(json['whiteKingPosition']),
      blackKingPosition: List<int>.from(json['blackKingPosition']),
      checkStatus: json['checkStatus'],
      enPassantTarget: json['enPassantTarget'] != null
          ? List<int>.from(json['enPassantTarget'])
          : null,
      lastMoveJson: json['lastMove'] != null
          ? Map<String, dynamic>.from(json['lastMove'])
          : null,
    );
  }
}
