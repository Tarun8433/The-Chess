// ignore_for_file: constant_identifier_names
import 'package:flutter/material.dart';
import 'package:the_chess/components/chess_timer.dart';
import 'package:the_chess/components/dead_piece.dart';
import 'package:the_chess/components/review_game.dart';
import 'package:the_chess/components/square.dart';
import 'package:the_chess/components/timer_widget.dart';
import 'package:the_chess/multiplayer/player_assignment.dart';
import 'package:the_chess/values/colors.dart';
import 'package:the_chess/components/pieces.dart'; // Import ChessPiece
import 'package:the_chess/components/move_history.dart'; // Import ChessMove

// Extend BoardGame to accept a callback for sending game state updates
class BoardGame extends StatefulWidget {
  final Function(
    List<List<ChessPiece?>> board,
    List<ChessPiece> whitePiecesTaken,
    List<ChessPiece> blackPiecesTaken,
    bool isWhiteTurn,
    List<int> whiteKingPosition,
    List<int> blackKingPosition,
    bool checkStatus,
    List<int>? enPassantTarget,
    ChessMove? lastMove,
  )? onGameStateUpdate;
  final bool isMultiplayer;
  final bool
      isLocalPlayerWhite; // Indicates if the local player is white in multiplayer
  final String name;
  const BoardGame({
    super.key,
    this.onGameStateUpdate,
    this.isMultiplayer = false,
    this.isLocalPlayerWhite = true,
    required this.name, // Default to white if not multiplayer
  });

  @override
  State<BoardGame> createState() => BoardGameState();
}

class BoardGameState extends State<BoardGame> {
  // ... existing variables ...
  late List<List<ChessPiece?>> board;
  late ChessTimer chessTimer;
  Duration whiteTime = Duration(minutes: 10);
  Duration blackTime = Duration(minutes: 10);
  bool gameEnded = false;
  ChessPiece? selectedPiece;
  int selectedRow = -1;
  int selectedCol = -1;
  List<List<int>> validMoves = [];
  List<ChessPiece> whitePiecesTaken = [];
  List<ChessPiece> blackPiecesTaken = [];
  bool isWhiteTurn = true;
  List<int> whiteKingPosition = [7, 4];
  List<int> blackKingPosition = [0, 4];
  bool checkStatus = false;
  List<int>? enPassantTarget;
  late PlayerAssignment
      playerAssignment; // Keep PlayerAssignment for single player logic
  late ReviewController reviewController;

  // Variables to store review state
  List<List<ChessPiece?>>? reviewBoard;
  List<ChessPiece>? reviewWhitePiecesTaken;
  List<ChessPiece>? reviewBlackPiecesTaken;
  bool? reviewIsWhiteTurn;
  List<int>? reviewWhiteKingPosition;
  List<int>? reviewBlackKingPosition;
  bool? reviewCheckStatus;
  List<int>? reviewEnPassantTarget;

  @override
  void initState() {
    super.initState();
    _initializeBoard();
    _initializeTimer();

    reviewController = ReviewController();
    playerAssignment = PlayerAssignment(); // Initialize PlayerAssignment

    // Set local player's color based on multiplayer flag
    if (widget.isMultiplayer) {
      // For multiplayer, directly set the internal state for player turn checking
      // Note: PlayerAssignment's _isLocalPlayerWhite is private.
      // We will bypass PlayerAssignment's _isLocalPlayerWhite for turn checking in multiplayer.
      // The `canSelectPiece` logic below will use `widget.isLocalPlayerWhite` directly.
    } else {
      playerAssignment
          .assignRandomColors(); // For single player, assign randomly
    }
  }

  // Method to apply received game state
  void applyGameState(
    List<List<Map<String, dynamic>?>> receivedBoard,
    List<Map<String, dynamic>> receivedWhitePiecesTaken,
    List<Map<String, dynamic>> receivedBlackPiecesTaken,
    bool receivedIsWhiteTurn,
    List<int> receivedWhiteKingPosition,
    List<int> receivedBlackKingPosition,
    bool receivedCheckStatus,
    List<int>? receivedEnPassantTarget,
    ChessMove? receivedLastMove,
  ) {
    setState(() {
      board = receivedBoard.map((row) {
        return row
            .map((pieceJson) =>
                pieceJson != null ? ChessPiece.fromJson(pieceJson) : null)
            .toList();
      }).toList();
      whitePiecesTaken =
          receivedWhitePiecesTaken.map((e) => ChessPiece.fromJson(e)).toList();
      blackPiecesTaken =
          receivedBlackPiecesTaken.map((e) => ChessPiece.fromJson(e)).toList();
      isWhiteTurn = receivedIsWhiteTurn;
      whiteKingPosition = receivedWhiteKingPosition;
      blackKingPosition = receivedBlackKingPosition;
      checkStatus = receivedCheckStatus;
      enPassantTarget = receivedEnPassantTarget;

      // Update timer based on the received turn
      // Assuming ChessTimer has an internal mechanism to manage turns and pause/start
      // based on `switchTurn()` and its `isWhiteTurn` property.
      // If the received turn is different from the current timer's active turn, switch it.
      if (chessTimer.isRunning) {
        // This assumes ChessTimer has a public getter for its current turn state.
        // If not, you'd need to add it to ChessTimer or manage this state here.
        // For now, assuming `chessTimer.isWhiteTurn` exists or `switchTurn` is smart.
        // The `isWhiteTurn` in `_BoardGameState` is the source of truth for the game logic.
        // The ChessTimer should just reflect this.
        if (isWhiteTurn != chessTimer.isWhiteTurn) {
          // Assuming chessTimer.isWhiteTurn exists
          chessTimer.switchTurn();
        }
      }

      // Add the move to review history if it's a new move
      if (receivedLastMove != null) {
        reviewController.addMove(receivedLastMove);
      }
    });
  }

  void movePiece(int newRow, int newCol) {
    if (reviewController.isInReviewMode) return;

    ChessPiece? capturedPiece;
    ChessPiece? enPassantCapturedPiece;
    bool wasEnPassant = false;
    bool wasPromotion = false;
    ChessPiecesType? promotedToType;
    List<int> previousKingPosition = selectedPiece!.type == ChessPiecesType.king
        ? (selectedPiece!.isWhite
            ? List<int>.from(whiteKingPosition)
            : List<int>.from(blackKingPosition))
        : [];

    List<int>? previousEnPassantTarget =
        enPassantTarget != null ? List<int>.from(enPassantTarget!) : null;

    if (selectedPiece?.type == ChessPiecesType.pawn &&
        enPassantTarget != null &&
        newRow == enPassantTarget![0] &&
        newCol == enPassantTarget![1]) {
      wasEnPassant = true;
      int capturedPawnRow = selectedPiece!.isWhite ? newRow + 1 : newRow - 1;
      enPassantCapturedPiece = board[capturedPawnRow][newCol];
      board[capturedPawnRow][newCol] = null;
    } else if (board[newRow][newCol] != null) {
      capturedPiece = board[newRow][newCol];
    }

    if (capturedPiece != null) {
      if (capturedPiece.isWhite) {
        whitePiecesTaken.add(capturedPiece);
      } else {
        blackPiecesTaken.add(capturedPiece);
      }
    }

    List<int>? newEnPassantTarget;
    if (selectedPiece?.type == ChessPiecesType.pawn) {
      int moveDistance = (newRow - selectedRow).abs();
      if (moveDistance == 2) {
        int enPassantRow = selectedPiece!.isWhite ? newRow + 1 : newRow - 1;
        newEnPassantTarget = [enPassantRow, newCol];
      }
    }

    if (selectedPiece?.type == ChessPiecesType.king) {
      if (selectedPiece!.isWhite) {
        whiteKingPosition = [newRow, newCol];
      } else {
        blackKingPosition = [newRow, newCol];
      }
    }

    board[newRow][newCol] = selectedPiece;
    board[selectedRow][selectedCol] = null;

    if (selectedPiece?.type == ChessPiecesType.pawn &&
        ((selectedPiece!.isWhite && newRow == 0) ||
            (!selectedPiece!.isWhite && newRow == 7))) {
      wasPromotion = true;
      promotedToType = ChessPiecesType.queen;
      board[newRow][newCol] = ChessPiece(
        type: ChessPiecesType.queen,
        isWhite: selectedPiece!.isWhite,
        imagePath: 'images/queen.png',
      );
    }

    enPassantTarget = newEnPassantTarget;

    bool wasCheck = isKingInCheck(!isWhiteTurn);
    bool wasCheckmate = false;

    if (wasCheck) {
      checkStatus = true;
      wasCheckmate = isCheckMate(!isWhiteTurn);
    } else {
      checkStatus = false;
    }

    ChessMove move = ChessMove(
      piece: selectedPiece!,
      fromRow: selectedRow,
      fromCol: selectedCol,
      toRow: newRow,
      toCol: newCol,
      capturedPiece: capturedPiece,
      wasEnPassant: wasEnPassant,
      enPassantCapturedPiece: enPassantCapturedPiece,
      previousEnPassantTarget: previousEnPassantTarget,
      newEnPassantTarget: newEnPassantTarget,
      wasPromotion: wasPromotion,
      promotedToType: promotedToType,
      wasCheck: wasCheck,
      wasCheckmate: wasCheckmate,
      previousKingPosition: previousKingPosition,
      moveNotation: _generateMoveNotation(selectedPiece!, selectedRow,
          selectedCol, newRow, newCol, capturedPiece != null),
      moveTime: DateTime.now().difference(DateTime.now()),
    );

    reviewController.addMove(move);

    if (chessTimer.isRunning) {
      chessTimer.switchTurn();
    }

    setState(() {
      selectedPiece = null;
      selectedRow = -1;
      selectedCol = -1;
      validMoves = [];
    });

    if (wasCheckmate) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text("CHECK MATE"),
          actions: [
            TextButton(
                onPressed: resetGame, child: const Text("Restart The Game"))
          ],
        ),
      );
    }

    isWhiteTurn = !isWhiteTurn;

    // Send game state update to the connected peer
    widget.onGameStateUpdate?.call(
      board,
      whitePiecesTaken,
      blackPiecesTaken,
      isWhiteTurn,
      whiteKingPosition,
      blackKingPosition,
      checkStatus,
      enPassantTarget,
      move, // Send the last move made
    );
  }

  void pieceSelected(int row, int col) {
    if (gameEnded) return;

    // Convert visual coordinates to actual board coordinates
    int actualRow = row;
    int actualCol = col;

    if (!widget.isLocalPlayerWhite) {
      actualRow = 7 - row; // Convert flipped row back to actual row
      actualCol = 7 - col; // Convert flipped col back to actual col
    }

    // Get the piece at the actual board position
    ChessPiece? pieceAtLocation = currentBoard[actualRow][actualCol];

    // Disable selection if in review mode
    if (reviewController.isInReviewMode) return;

    setState(() {
      // Logic for piece selection based on game mode (single vs multiplayer) and turn
      bool canSelect = false;

      if (widget.isMultiplayer) {
        // In multiplayer, a player can only select their own pieces when it's their turn
        if (pieceAtLocation != null) {
          bool isPieceOwnedByLocalPlayer =
              pieceAtLocation.isWhite == widget.isLocalPlayerWhite;
          bool isLocalPlayersTurn = isWhiteTurn == widget.isLocalPlayerWhite;
          canSelect = isPieceOwnedByLocalPlayer && isLocalPlayersTurn;

          // Debug debugPrints
          debugPrint('Multiplayer piece selection:');
          debugPrint('  Piece is white: ${pieceAtLocation.isWhite}');
          debugPrint('  Local player is white: ${widget.isLocalPlayerWhite}');
          debugPrint('  Current turn is white: $isWhiteTurn');
          debugPrint(
              '  Piece owned by local player: $isPieceOwnedByLocalPlayer');
          debugPrint('  Is local players turn: $isLocalPlayersTurn');
          debugPrint('  Can select: $canSelect');
          debugPrint(
              '  Visual position: ($row, $col), Actual position: ($actualRow, $actualCol)');
        }
      } else {
        // In single player, use the PlayerAssignment logic
        canSelect = (pieceAtLocation != null &&
            playerAssignment.canSelectPiece(
                pieceAtLocation.isWhite, isWhiteTurn));
      }

      // Condition 1: No piece currently selected, and a piece is tapped
      if (selectedPiece == null && canSelect) {
        selectedPiece = pieceAtLocation;
        selectedRow = actualRow; // Store actual row
        selectedCol = actualCol; // Store actual col
        debugPrint(
            'Piece selected: ${selectedPiece!.type} at actual position ($actualRow, $actualCol), visual position ($row, $col)');

        // Start timer only if it's not running and a piece is selected for the first time
        if (chessTimer.isStopped) {
          chessTimer.startTimer();
        }
      }
      // Condition 2: A piece is already selected, and a new piece of the same color is tapped
      else if (pieceAtLocation != null && selectedPiece != null && canSelect) {
        // Allow re-selection of own pieces
        selectedPiece = pieceAtLocation;
        selectedRow = actualRow; // Store actual row
        selectedCol = actualCol; // Store actual col
        debugPrint(
            'Piece re-selected: ${selectedPiece!.type} at actual position ($actualRow, $actualCol), visual position ($row, $col)');
      }
      // Condition 3: A piece is selected, and a valid empty square or opponent's piece is tapped
      else if (selectedPiece != null &&
          validMoves.any((element) =>
              element[0] == actualRow && element[1] == actualCol)) {
        // Double-check that it's the local player's turn and they own the selected piece
        bool canMakeMove = false;
        if (widget.isMultiplayer) {
          bool pieceOwnedByLocalPlayer =
              selectedPiece!.isWhite == widget.isLocalPlayerWhite;
          bool isLocalPlayersTurn = isWhiteTurn == widget.isLocalPlayerWhite;
          canMakeMove = pieceOwnedByLocalPlayer && isLocalPlayersTurn;

          debugPrint('Attempting move:');
          debugPrint('  Selected piece is white: ${selectedPiece!.isWhite}');
          debugPrint('  Local player is white: ${widget.isLocalPlayerWhite}');
          debugPrint('  Current turn is white: $isWhiteTurn');
          debugPrint('  Can make move: $canMakeMove');
          debugPrint(
              '  Moving to actual position: ($actualRow, $actualCol), visual position: ($row, $col)');
        } else {
          canMakeMove = playerAssignment.canSelectPiece(
              selectedPiece!.isWhite, isWhiteTurn);
        }

        if (canMakeMove) {
          debugPrint(
              'Making move from ($selectedRow, $selectedCol) to ($actualRow, $actualCol)');
          movePiece(
              actualRow, actualCol); // Use actual coordinates for the move
        } else {
          debugPrint('Move blocked - not local player\'s turn or piece');
        }
      }

      // Always recalculate valid moves for the currently selected piece (if any)
      if (selectedPiece != null) {
        validMoves = calculateRealValidMoves(
            selectedRow, selectedCol, selectedPiece, true);
        debugPrint('Valid moves calculated: ${validMoves.length} moves');
        debugPrint('Valid moves: $validMoves');
      } else {
        validMoves = []; // Clear valid moves if no piece is selected
      }
    });
  }
  // void pieceSelected(int row, int col) {
  //   if (gameEnded) return;

  //   // Get the piece at the selected position
  //   ChessPiece? pieceAtLocation = currentBoard[row][col];

  //   // Disable selection if in review mode
  //   if (reviewController.isInReviewMode) return;

  //   setState(() {
  //     // Logic for piece selection based on game mode (single vs multiplayer) and turn
  //     bool canSelect = false;

  //     if (widget.isMultiplayer) {
  //       // In multiplayer, a player can only select their own pieces when it's their turn
  //       if (pieceAtLocation != null) {
  //         bool isPieceOwnedByLocalPlayer =
  //             pieceAtLocation.isWhite == widget.isLocalPlayerWhite;
  //         bool isLocalPlayersTurn = isWhiteTurn == widget.isLocalPlayerWhite;
  //         canSelect = isPieceOwnedByLocalPlayer && isLocalPlayersTurn;

  //         // Debug debugPrints to help diagnose issues
  //         debugPrint('Multiplayer piece selection:');
  //         debugPrint('  Piece is white: ${pieceAtLocation.isWhite}');
  //         debugPrint('  Local player is white: ${widget.isLocalPlayerWhite}');
  //         debugPrint('  Current turn is white: $isWhiteTurn');
  //         debugPrint('  Piece owned by local player: $isPieceOwnedByLocalPlayer');
  //         debugPrint('  Is local players turn: $isLocalPlayersTurn');
  //         debugPrint('  Can select: $canSelect');
  //       }
  //     } else {
  //       // In single player, use the PlayerAssignment logic
  //       canSelect = (pieceAtLocation != null &&
  //           playerAssignment.canSelectPiece(
  //               pieceAtLocation.isWhite, isWhiteTurn));
  //     }

  //     // Condition 1: No piece currently selected, and a piece is tapped
  //     if (selectedPiece == null && canSelect) {
  //       selectedPiece = pieceAtLocation;
  //       selectedRow = row;
  //       selectedCol = col;
  //       debugPrint('Piece selected: ${selectedPiece!.type} at ($row, $col)');

  //       // Start timer only if it's not running and a piece is selected for the first time
  //       if (chessTimer.isStopped) {
  //         chessTimer.startTimer();
  //       }
  //     }
  //     // Condition 2: A piece is already selected, and a new piece of the same color is tapped
  //     else if (pieceAtLocation != null && selectedPiece != null && canSelect) {
  //       // Allow re-selection of own pieces
  //       selectedPiece = pieceAtLocation;
  //       selectedRow = row;
  //       selectedCol = col;
  //       debugPrint('Piece re-selected: ${selectedPiece!.type} at ($row, $col)');
  //     }
  //     // Condition 3: A piece is selected, and a valid empty square or opponent's piece is tapped
  //     else if (selectedPiece != null &&
  //         validMoves.any((element) => element[0] == row && element[1] == col)) {
  //       // Double-check that it's the local player's turn and they own the selected piece
  //       bool canMakeMove = false;
  //       if (widget.isMultiplayer) {
  //         bool pieceOwnedByLocalPlayer =
  //             selectedPiece!.isWhite == widget.isLocalPlayerWhite;
  //         bool isLocalPlayersTurn = isWhiteTurn == widget.isLocalPlayerWhite;
  //         canMakeMove = pieceOwnedByLocalPlayer && isLocalPlayersTurn;

  //         debugPrint('Attempting move:');
  //         debugPrint('  Selected piece is white: ${selectedPiece!.isWhite}');
  //         debugPrint('  Local player is white: ${widget.isLocalPlayerWhite}');
  //         debugPrint('  Current turn is white: $isWhiteTurn');
  //         debugPrint('  Can make move: $canMakeMove');
  //       } else {
  //         canMakeMove = playerAssignment.canSelectPiece(
  //             selectedPiece!.isWhite, isWhiteTurn);
  //       }

  //       if (canMakeMove) {
  //         debugPrint(
  //             'Making move from ($selectedRow, $selectedCol) to ($row, $col)');
  //         movePiece(row, col);
  //       } else {
  //         debugPrint('Move blocked - not local player\'s turn or piece');
  //       }
  //     }

  //     // Always recalculate valid moves for the currently selected piece (if any)
  //     if (selectedPiece != null) {
  //       validMoves = calculateRealValidMoves(
  //           selectedRow, selectedCol, selectedPiece, true);
  //       debugPrint('Valid moves calculated: ${validMoves.length} moves');
  //     } else {
  //       validMoves = []; // Clear valid moves if no piece is selected
  //     }
  //   });
  // }

  void startReview() {
    if (!reviewController.canStartReview()) return;

    reviewController.startReview(
      board,
      whitePiecesTaken,
      blackPiecesTaken,
      isWhiteTurn,
      whiteKingPosition,
      blackKingPosition,
      checkStatus,
      enPassantTarget,
    );

    _updateReviewState();
    setState(() {});
  }

  void endReview() {
    reviewController.endReview();

    // Clear review state
    reviewBoard = null;
    reviewWhitePiecesTaken = null;
    reviewBlackPiecesTaken = null;
    reviewIsWhiteTurn = null;
    reviewWhiteKingPosition = null;
    reviewBlackKingPosition = null;
    reviewCheckStatus = null;
    reviewEnPassantTarget = null;

    setState(() {});
  }

  void goToPreviousMove() {
    reviewController.goToPreviousMove();
    _updateReviewState();
    setState(() {});
  }

  void goToNextMove() {
    reviewController.goToNextMove();
    _updateReviewState();
    setState(() {});
  }

  void goToSpecificMove(int moveIndex) {
    if (reviewController.isInReviewMode &&
        moveIndex >= 0 &&
        moveIndex < reviewController.moveHistory.length) {
      reviewController.goToMove(moveIndex);
      _updateReviewState();
      setState(() {});
    }
  }

  void _updateReviewState() {
    if (!reviewController.isInReviewMode) return;

    Map<String, dynamic> boardState = reviewController
        .getBoardStateAtMove(reviewController.currentReviewIndex);

    if (boardState.isNotEmpty) {
      reviewBoard = boardState['board'];
      reviewWhitePiecesTaken = boardState['whitePiecesTaken'];
      reviewBlackPiecesTaken = boardState['blackPiecesTaken'];
      reviewIsWhiteTurn = boardState['isWhiteTurn'];
      reviewWhiteKingPosition = boardState['whiteKingPosition'];
      reviewBlackKingPosition = boardState['blackKingPosition'];
      reviewCheckStatus = boardState['checkStatus'];
      reviewEnPassantTarget = boardState['enPassantTarget'];
    }
  }

  String _generateMoveNotation(ChessPiece piece, int fromRow, int fromCol,
      int toRow, int toCol, bool isCapture) {
    String fromPos =
        '${String.fromCharCode('a'.codeUnitAt(0) + fromCol)}${8 - fromRow}';
    String toPos =
        '${String.fromCharCode('a'.codeUnitAt(0) + toCol)}${8 - toRow}';
    String pieceSymbol =
        piece.type.toString().split('.').last.substring(0, 1).toUpperCase();

    if (piece.type == ChessPiecesType.pawn) {
      return isCapture ? '${fromPos.substring(0, 1)}x$toPos' : toPos;
    }

    return isCapture
        ? '$pieceSymbol${fromPos}x$toPos'
        : '$pieceSymbol$fromPos-$toPos';
  }

  List<List<ChessPiece?>> get currentBoard =>
      reviewController.isInReviewMode ? reviewBoard ?? board : board;
  List<ChessPiece> get currentWhitePiecesTaken =>
      reviewController.isInReviewMode
          ? reviewWhitePiecesTaken ?? whitePiecesTaken
          : whitePiecesTaken;
  List<ChessPiece> get currentBlackPiecesTaken =>
      reviewController.isInReviewMode
          ? reviewBlackPiecesTaken ?? blackPiecesTaken
          : blackPiecesTaken;
  bool get currentIsWhiteTurn => reviewController.isInReviewMode
      ? reviewIsWhiteTurn ?? isWhiteTurn
      : isWhiteTurn;
  bool get currentCheckStatus => reviewController.isInReviewMode
      ? reviewCheckStatus ?? checkStatus
      : checkStatus;
  List<int> get currentWhiteKingPosition => reviewController.isInReviewMode
      ? reviewWhiteKingPosition ?? whiteKingPosition
      : whiteKingPosition;
  List<int> get currentBlackKingPosition => reviewController.isInReviewMode
      ? reviewBlackKingPosition ?? blackKingPosition
      : blackKingPosition;

  void _initializeTimer() {
    chessTimer = ChessTimer.customTimer(
      onTimeUpdate: (Duration white, Duration black) {
        if (mounted) {
          setState(() {
            whiteTime = white;
            blackTime = black;
          });
        }
      },
      onTimeUp: (bool isWhiteWinner) {
        if (mounted) {
          setState(() {
            gameEnded = true;
          });
          _showTimeUpDialog(isWhiteWinner);
        }
      },
      initialTime: Duration(minutes: 5),
    );

    whiteTime = chessTimer.whiteTime;
    blackTime = chessTimer.blackTime;
  }

  void _initializeBoard() {
    List<List<ChessPiece?>> newBoard =
        List.generate(8, (index) => List.generate(8, (index) => null));

    for (int i = 0; i < 8; i++) {
      newBoard[1][i] = ChessPiece(
        type: ChessPiecesType.pawn,
        isWhite: false,
        imagePath: 'images/pawn.png',
      );

      newBoard[6][i] = ChessPiece(
        type: ChessPiecesType.pawn,
        isWhite: true,
        imagePath: 'images/pawn.png',
      );
    }

    newBoard[0][0] = ChessPiece(
        type: ChessPiecesType.rook,
        isWhite: false,
        imagePath: "images/rook.png");
    newBoard[0][7] = ChessPiece(
        type: ChessPiecesType.rook,
        isWhite: false,
        imagePath: "images/rook.png");
    newBoard[7][0] = ChessPiece(
        type: ChessPiecesType.rook,
        isWhite: true,
        imagePath: "images/rook.png");
    newBoard[7][7] = ChessPiece(
        type: ChessPiecesType.rook,
        isWhite: true,
        imagePath: "images/rook.png");

    newBoard[0][1] = ChessPiece(
        type: ChessPiecesType.knight,
        isWhite: false,
        imagePath: "images/knight.png");
    newBoard[0][6] = ChessPiece(
        type: ChessPiecesType.knight,
        isWhite: false,
        imagePath: "images/knight.png");
    newBoard[7][1] = ChessPiece(
        type: ChessPiecesType.knight,
        isWhite: true,
        imagePath: "images/knight.png");
    newBoard[7][6] = ChessPiece(
        type: ChessPiecesType.knight,
        isWhite: true,
        imagePath: "images/knight.png");

    newBoard[0][2] = ChessPiece(
        type: ChessPiecesType.bishop,
        isWhite: false,
        imagePath: "images/bishop.png");

    newBoard[0][5] = ChessPiece(
        type: ChessPiecesType.bishop,
        isWhite: false,
        imagePath: "images/bishop.png");
    newBoard[7][2] = ChessPiece(
        type: ChessPiecesType.bishop,
        isWhite: true,
        imagePath: "images/bishop.png");
    newBoard[7][5] = ChessPiece(
        type: ChessPiecesType.bishop,
        isWhite: true,
        imagePath: "images/bishop.png");

    newBoard[0][3] = ChessPiece(
      type: ChessPiecesType.queen,
      isWhite: false,
      imagePath: 'images/queen.png',
    );
    newBoard[7][3] = ChessPiece(
      type: ChessPiecesType.queen,
      isWhite: true,
      imagePath: 'images/queen.png',
    );

    newBoard[0][4] = ChessPiece(
      type: ChessPiecesType.king,
      isWhite: false,
      imagePath: 'images/king.png',
    );
    newBoard[7][4] = ChessPiece(
      type: ChessPiecesType.king,
      isWhite: true,
      imagePath: 'images/king.png',
    );

    board = newBoard;
  }

  List<List<int>> calculateRowValidMoves(int row, int col, ChessPiece? piece) {
    List<List<int>> candidateMoves = [];

    if (piece == null) return [];

    int direction = piece.isWhite ? -1 : 1;

    switch (piece.type) {
      case ChessPiecesType.pawn:
        if (isInBoard(row + direction, col) &&
            board[row + direction][col] == null) {
          candidateMoves.add([row + direction, col]);
          if ((row == 6 && piece.isWhite) || (row == 1 && !piece.isWhite)) {
            if (board[row + 2 * direction][col] == null) {
              candidateMoves.add([row + 2 * direction, col]);
            }
          }
        }
        for (int sideCol in [col - 1, col + 1]) {
          if (isInBoard(row + direction, sideCol) &&
              board[row + direction][sideCol] != null &&
              board[row + direction][sideCol]!.isWhite != piece.isWhite) {
            candidateMoves.add([row + direction, sideCol]);
          }
        }

        if (enPassantTarget != null) {
          int targetRow = enPassantTarget![0];
          int targetCol = enPassantTarget![1];

          if (row + direction == targetRow &&
              (col - 1 == targetCol || col + 1 == targetCol)) {
            candidateMoves.add([targetRow, targetCol]);
          }
        }
        break;

      case ChessPiecesType.rook:
        var directions = [
          [-1, 0],
          [1, 0],
          [0, -1],
          [0, 1]
        ];
        for (var dir in directions) {
          int i = 1;
          while (true) {
            int newRow = row + i * dir[0];
            int newCol = col + i * dir[1];
            if (!isInBoard(newRow, newCol)) break;
            if (board[newRow][newCol] != null) {
              if (board[newRow][newCol]!.isWhite != piece.isWhite) {
                candidateMoves.add([newRow, newCol]);
              }
              break;
            }
            candidateMoves.add([newRow, newCol]);
            i++;
          }
        }
        break;

      case ChessPiecesType.knight:
        var moves = [
          [-2, -1],
          [-2, 1],
          [-1, -2],
          [-1, 2],
          [1, -2],
          [1, 2],
          [2, -1],
          [2, 1],
        ];
        for (var move in moves) {
          int newRow = row + move[0];
          int newCol = col + move[1];
          if (!isInBoard(newRow, newCol)) continue;
          if (board[newRow][newCol] == null ||
              board[newRow][newCol]!.isWhite != piece.isWhite) {
            candidateMoves.add([newRow, newCol]);
          }
        }
        break;

      case ChessPiecesType.bishop:
        var directions = [
          [-1, -1],
          [-1, 1],
          [1, -1],
          [1, 1]
        ];
        for (var dir in directions) {
          int i = 1;
          while (true) {
            int newRow = row + i * dir[0];
            int newCol = col + i * dir[1];
            if (!isInBoard(newRow, newCol)) break;
            if (board[newRow][newCol] != null) {
              if (board[newRow][newCol]!.isWhite != piece.isWhite) {
                candidateMoves.add([newRow, newCol]);
              }
              break;
            }
            candidateMoves.add([newRow, newCol]);
            i++;
          }
        }
        break;

      case ChessPiecesType.queen:
        var directions = [
          [-1, 0],
          [1, 0],
          [0, -1],
          [0, 1],
          [-1, -1],
          [-1, 1],
          [1, -1],
          [1, 1]
        ];
        for (var dir in directions) {
          int i = 1;
          while (true) {
            int newRow = row + i * dir[0];
            int newCol = col + i * dir[1];
            if (!isInBoard(newRow, newCol)) break;
            if (board[newRow][newCol] != null) {
              if (board[newRow][newCol]!.isWhite != piece.isWhite) {
                candidateMoves.add([newRow, newCol]);
              }
              break;
            }
            candidateMoves.add([newRow, newCol]);
            i++;
          }
        }
        break;

      case ChessPiecesType.king:
        var moves = [
          [-1, -1],
          [-1, 0],
          [-1, 1],
          [0, -1],
          [0, 1],
          [1, -1],
          [1, 0],
          [1, 1]
        ];
        for (var move in moves) {
          int newRow = row + move[0];
          int newCol = col + move[1];
          if (!isInBoard(newRow, newCol)) continue;
          if (board[newRow][newCol] == null ||
              board[newRow][newCol]!.isWhite != piece.isWhite) {
            candidateMoves.add([newRow, newCol]);
          }
        }
        break;
    }

    return candidateMoves;
  }

  List<List<int>> calculateRealValidMoves(
      int row, int col, ChessPiece? piece, bool checkSimulation) {
    List<List<int>> realValidMoves = [];
    List<List<int>> candidateMoves = calculateRowValidMoves(row, col, piece);
    if (checkSimulation) {
      for (var move in candidateMoves) {
        int endRow = move[0];
        int endCol = move[1];
        if (simulatedMoveIsSafe(piece!, row, col, endRow, endCol)) {
          realValidMoves.add(move);
        }
      }
    } else {
      realValidMoves = candidateMoves;
    }
    return realValidMoves;
  }

  bool isKingInCheck(bool isWhiteKing) {
    List<int> kingPosition =
        isWhiteKing ? whiteKingPosition : blackKingPosition;

    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 8; j++) {
        if (board[i][j] == null || board[i][j]!.isWhite == isWhiteKing) {
          continue;
        }
        List<List<int>> pieceValidMoves =
            calculateRealValidMoves(i, j, board[i][j], false);

        for (List<int> move in pieceValidMoves) {
          if (move[0] == kingPosition[0] && move[1] == kingPosition[1]) {
            return true;
          }
        }
      }
    }
    return false;
  }

  bool simulatedMoveIsSafe(
      ChessPiece piece, int startRow, int startCol, int endRow, int endCol) {
    ChessPiece? originalDestinationPiece = board[endRow][endCol];
    ChessPiece? originalEnPassantPiece;

    bool isSimulatedEnPassant = false;
    if (piece.type == ChessPiecesType.pawn &&
        enPassantTarget != null &&
        endRow == enPassantTarget![0] &&
        endCol == enPassantTarget![1]) {
      isSimulatedEnPassant = true;
      int capturedPawnRow = piece.isWhite ? endRow + 1 : endRow - 1;
      originalEnPassantPiece = board[capturedPawnRow][endCol];
      board[capturedPawnRow][endCol] = null;
    }

    List<int>? originalKingPosition;
    if (piece.type == ChessPiecesType.king) {
      originalKingPosition =
          piece.isWhite ? whiteKingPosition : blackKingPosition;

      if (piece.isWhite) {
        whiteKingPosition = [endRow, endCol];
      } else {
        blackKingPosition = [endRow, endCol];
      }
    }

    board[endRow][endCol] = piece;
    board[startRow][startCol] = null;

    bool kingInCheck = isKingInCheck(piece.isWhite);

    board[startRow][startCol] = piece;
    board[endRow][endCol] = originalDestinationPiece;

    if (isSimulatedEnPassant) {
      int capturedPawnRow = piece.isWhite ? endRow + 1 : endRow - 1;
      board[capturedPawnRow][endCol] = originalEnPassantPiece;
    }

    if (piece.type == ChessPiecesType.king) {
      if (piece.isWhite) {
        whiteKingPosition = originalKingPosition!;
      } else {
        blackKingPosition = originalKingPosition!;
      }
    }
    return !kingInCheck;
  }

  bool isWhite(int index) {
    int row = index ~/ 8;
    int col = index % 8;
    // Invert row if local player is black
    if (widget.isMultiplayer && !widget.isLocalPlayerWhite) {
      row = 7 - row;
    }
    return (row + col) % 2 == 0;
  }

  bool isInBoard(int row, int col) {
    return row >= 0 && row < 8 && col >= 0 && col < 8;
  }

  bool isCheckMate(bool isWhiteKing) {
    if (!isKingInCheck(isWhiteKing)) {
      return false;
    }
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 8; j++) {
        if (board[i][j] == null || board[i][j]!.isWhite != isWhiteKing) {
          continue;
        }
        List<List<int>> validMoves =
            calculateRealValidMoves(i, j, board[i][j]!, true);
        if (validMoves.isNotEmpty) {
          return false;
        }
      }
    }
    return true;
  }

  void resetGame() {
    // Check if the current context is still valid before popping
    if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    }
    _initializeBoard();
    checkStatus = false;
    whitePiecesTaken.clear();
    blackPiecesTaken.clear();
    whiteKingPosition = [7, 4];
    blackKingPosition = [0, 4];
    isWhiteTurn = true;
    enPassantTarget = null;

    gameEnded = false;
    chessTimer.reset();
    whiteTime = chessTimer.whiteTime;
    blackTime = chessTimer.blackTime;

    setState(() {});
  }

  @override
  void dispose() {
    chessTimer.dispose();
    super.dispose();
  }

  void _showTimeUpDialog(bool isWhiteWinner) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(
              Icons.timer_off,
              color: Colors.red,
              size: 24,
            ),
            SizedBox(width: 8),
            Text(
              "Time's Up!",
              style: TextStyle(
                color: Colors.red,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              isWhiteWinner ? Icons.emoji_events : Icons.emoji_events,
              color: isWhiteWinner ? Colors.amber : Colors.grey,
              size: 48,
            ),
            SizedBox(height: 16),
            Text(
              isWhiteWinner
                  ? "Black ran out of time.\nWhite wins!"
                  : "White ran out of time.\nBlack wins!",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(height: 12),
            Text(
              "Game Over",
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text(
              "View Board",
              style: TextStyle(color: Colors.grey[600]),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              resetGame();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue,
              foregroundColor: Colors.white,
            ),
            child: Text("New Game"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          reviewController.isInReviewMode ? Colors.orange[200] : Colors.white30,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          SafeArea(
            child: ReviewStatusBanner(
              isInReviewMode: reviewController.isInReviewMode,
              statusText: reviewController.isInReviewMode
                  ? 'REVIEWING MOVES - TIMER CONTINUES'
                  : 'Game On',
            ),
          ),
          // Player info at the top (opponent for local white, self for local black)
          if (widget
              .isLocalPlayerWhite) // Local player is White, opponent is Black (top)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.white)),
                        child: Image.asset(
                          "assets/images/figures/white/queen.png",
                          height: 50,
                          color: Colors.black, // Opponent is black
                        ),
                      ),
                      SizedBox(width: 8),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Opponent", // Replace with actual opponent name if available
                            style: TextStyle(
                              color: reviewController.isInReviewMode
                                  ? Colors.black
                                  : Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                          SizedBox(
                            height: 30,
                            width: MediaQuery.of(context).size.width * .6,
                            child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              physics: const BouncingScrollPhysics(),
                              itemCount: currentBlackPiecesTaken.length,
                              itemBuilder: (context, index) => DeadPiece(
                                imagePath:
                                    currentBlackPiecesTaken[index].imagePath,
                                isWhite: false,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  ChessTimerDisplayForBlack(
                    chessTimer: chessTimer,
                    whiteTime: whiteTime,
                    blackTime: blackTime,
                  ),
                ],
              ),
            )
          else // Local player is Black, opponent is White (top)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.white)),
                        child: Image.asset(
                          "assets/images/figures/white/queen.png",
                          height: 50,
                          color: Colors.white, // Opponent is white
                        ),
                      ),
                      SizedBox(width: 8),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Opponent", // Replace with actual opponent name if available
                            style: TextStyle(
                              color: reviewController.isInReviewMode
                                  ? Colors.black
                                  : Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                          SizedBox(
                            height: 30,
                            width: MediaQuery.of(context).size.width * .6,
                            child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              physics: const BouncingScrollPhysics(),
                              itemCount: currentWhitePiecesTaken.length,
                              itemBuilder: (context, index) => DeadPiece(
                                imagePath:
                                    currentWhitePiecesTaken[index].imagePath,
                                isWhite: true,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  ChessTimerDisplayForWhite(
                    chessTimer: chessTimer,
                    whiteTime: whiteTime,
                    blackTime: blackTime,
                  ),
                ],
              ),
            ),

          Spacer(),
// Updated GridView.builder in the build method
          AspectRatio(
            aspectRatio: .9,
            child: GridView.builder(
              physics: const NeverScrollableScrollPhysics(),
              itemCount: 64,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 8),
              itemBuilder: (context, index) {
                int row = index ~/ 8;
                int col = index % 8;

                // These are the visual coordinates after potential flipping
                int visualRow = row;
                int visualCol = col;

                // Calculate actual board coordinates based on player orientation
                int actualRow = row;
                int actualCol = col;

                // If local player is black, flip the board so black pieces appear at bottom
                if (!widget.isLocalPlayerWhite) {
                  actualRow = 7 - row; // Flip rows
                  actualCol =
                      7 - col; // Flip columns too for proper orientation

                  // Update visual coordinates for display
                  visualRow = row;
                  visualCol = col;
                }

                bool isSelected = !reviewController.isInReviewMode &&
                    selectedCol == actualCol &&
                    selectedRow == actualRow;

                bool isValidMove = false;

                if (!reviewController.isInReviewMode) {
                  for (var position in validMoves) {
                    // position contains actual board coordinates
                    if (position[0] == actualRow && position[1] == actualCol) {
                      isValidMove = true;
                      break;
                    }
                  }
                }

                return Square1(
                  isValidMove: isValidMove,
                  onTap: reviewController.isInReviewMode
                      ? null
                      : () => pieceSelected(visualRow, visualCol),
                  isSelected: isSelected,
                  isWhite: isWhite(index), // Board square color pattern
                  piece: currentBoard[actualRow]
                      [actualCol], // Piece from actual position
                  isKingInCheck: currentBoard[actualRow][actualCol] != null &&
                      currentBoard[actualRow][actualCol]!.type ==
                          ChessPiecesType.king &&
                      _isKingInCheckAtCurrentState(
                          currentBoard[actualRow][actualCol]!.isWhite),
                  boardBColor: reviewController.isInReviewMode
                      ? Colors.orange
                      : forgroundColor,
                  boardWColor: backgroundColor,
                );
              },
            ),
          ),
          // AspectRatio(
          //   aspectRatio: .9,
          //   child: GridView.builder(
          //     physics: const NeverScrollableScrollPhysics(),
          //     itemCount: 64,
          //     gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          //         crossAxisCount: 8),
          //     itemBuilder: (context, index) {
          //       int row = index ~/ 8;
          //       int col = index % 8;

          //       // Flip the board if the local player is Black
          //       if (!widget.isLocalPlayerWhite) {
          //         row = 7 - row;
          //         // col = 7 - col; // Only flip rows, not columns typically for chess
          //       }

          //       bool isSelected = !reviewController.isInReviewMode &&
          //           selectedCol == col &&
          //           selectedRow == row;
          //       bool isValidMove = false;

          //       if (!reviewController.isInReviewMode) {
          //         for (var position in validMoves) {
          //           // Adjust valid move positions if the board is flipped
          //           int validMoveRow = widget.isLocalPlayerWhite
          //               ? position[0]
          //               : 7 - position[0];
          //           // int validMoveCol = widget.isLocalPlayerWhite ? position[1] : 7 - position[1]; // Not flipping columns

          //           if (validMoveRow == row && position[1] == col) {
          //             isValidMove = true;
          //           }
          //         }
          //       }

          //       return Square(
          //         isValidMove: isValidMove,
          //         onTap: reviewController.isInReviewMode
          //             ? null
          //             : () => pieceSelected(row, col),
          //         isSelected: isSelected,
          //         isWhite: isWhite(
          //             index), // isWhite considers the original board layout
          //         piece: currentBoard[row]
          //             [col], // Pass piece from the original board layout
          //         isKingInCheck: currentBoard[row][col] != null &&
          //             currentBoard[row][col]!.type == ChessPiecesType.king &&
          //             _isKingInCheckAtCurrentState(
          //                 currentBoard[row][col]!.isWhite),
          //         boardBColor: reviewController.isInReviewMode
          //             ? Colors.orange
          //             : forgroundColor,
          //         boardWColor: backgroundColor,
          //       );
          //     },
          //   ),
          // ),

          Spacer(),

          // Player info at the bottom (self for local white, opponent for local black)
          if (widget.isLocalPlayerWhite) // Local player is White (bottom)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.white)),
                        child: Image.asset(
                          "assets/images/figures/white/queen.png",
                          height: 50,
                          color: Colors.white, // Local player is white
                        ),
                      ),
                      SizedBox(width: 8),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.name,
                            style: TextStyle(
                              color: reviewController.isInReviewMode
                                  ? Colors.black
                                  : Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                          SizedBox(
                            height: 30,
                            width: MediaQuery.of(context).size.width * .6,
                            child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              physics: const BouncingScrollPhysics(),
                              itemCount: currentWhitePiecesTaken.length,
                              itemBuilder: (context, index) => DeadPiece(
                                imagePath:
                                    currentWhitePiecesTaken[index].imagePath,
                                isWhite: true,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  ChessTimerDisplayForWhite(
                    chessTimer: chessTimer,
                    whiteTime: whiteTime,
                    blackTime: blackTime,
                  ),
                ],
              ),
            )
          else // Local player is Black (bottom)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.white)),
                        child: Image.asset(
                          "assets/images/figures/white/queen.png",
                          height: 50,
                          color: Colors.black, // Local player is black
                        ),
                      ),
                      SizedBox(width: 8),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.name,
                            style: TextStyle(
                              color: reviewController.isInReviewMode
                                  ? Colors.black
                                  : Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                          SizedBox(
                            height: 30,
                            width: MediaQuery.of(context).size.width * .6,
                            child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              physics: const BouncingScrollPhysics(),
                              itemCount: currentBlackPiecesTaken.length,
                              itemBuilder: (context, index) => DeadPiece(
                                imagePath:
                                    currentBlackPiecesTaken[index].imagePath,
                                isWhite: false,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  ChessTimerDisplayForBlack(
                    chessTimer: chessTimer,
                    whiteTime: whiteTime,
                    blackTime: blackTime,
                  ),
                ],
              ),
            ),
          ReviewControls(
            onPrevious: goToPreviousMove,
            onNext: goToNextMove,
            canGoBack: reviewController.canGoBack(),
            canGoForward: reviewController.canGoForward(),
            currentMoveInfo: reviewController.getCurrentMoveInfo(),
            onExitReview: endReview,
            startReview:
                reviewController.isInReviewMode ? endReview : startReview,
            canStartReview: reviewController.canStartReview(),
            isInReviewMode: reviewController.isInReviewMode,
          )
        ],
      ),
    );
  }

  bool _isKingInCheckAtCurrentState(bool isWhiteKing) {
    if (reviewController.isInReviewMode) {
      return currentCheckStatus &&
          ((isWhiteKing && !currentIsWhiteTurn) ||
              (!isWhiteKing && currentIsWhiteTurn));
    }
    return isKingInCheck(isWhiteKing);
  }
}
